(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["chunk-0178da9a"],{

/***/ "0463":
/*!*************************************************************************************!*\
  !*** ./src/views/resource/project/project/index.vue?vue&type=template&id=8654e95e& ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_index_vue_vue_type_template_id_8654e95e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./index.vue?vue&type=template&id=8654e95e& */ "c964");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_index_vue_vue_type_template_id_8654e95e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_index_vue_vue_type_template_id_8654e95e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "1afc":
/*!*****************************************************************************************!*\
  !*** ./src/views/resource/project/project/tableList.vue?vue&type=template&id=b44db39e& ***!
  \*****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_tableList_vue_vue_type_template_id_b44db39e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./tableList.vue?vue&type=template&id=b44db39e& */ "7dae3");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_tableList_vue_vue_type_template_id_b44db39e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_tableList_vue_vue_type_template_id_b44db39e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "4e36":
/*!***********************************************************************************!*\
  !*** ./src/views/resource/project/project/tableList.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_tableList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./tableList.vue?vue&type=script&lang=js& */ "60c5d");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_tableList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "4e8b":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/resource/project/project/formSearch.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _config_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./config/data */ "8b30");

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      form: this.$deepCopy(_config_data__WEBPACK_IMPORTED_MODULE_0__["searchForm"]),
      defaultForm: this.$deepCopy(_config_data__WEBPACK_IMPORTED_MODULE_0__["searchForm"])
    };
  },
  methods: {
    // 查询列表信息
    search: function search() {
      var vm = this;
      vm.$store.commit("project/formSearch", vm.$deepCopy(vm.form));
    }
  },
  mounted: function mounted() {
    // 默认查询一次
    this.search();
  }
});

/***/ }),

/***/ "5908":
/*!************************************************************!*\
  !*** ./src/views/resource/project/project/config/ports.js ***!
  \************************************************************/
/*! exports provided: searchPlacingAccPage, getProjectList, getLeaderList, createProject, getProject, updProject, updProjectCare */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchPlacingAccPage", function() { return searchPlacingAccPage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getProjectList", function() { return getProjectList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLeaderList", function() { return getLeaderList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createProject", function() { return createProject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getProject", function() { return getProject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updProject", function() { return updProject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updProjectCare", function() { return updProjectCare; });
/* harmony import */ var _request_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/request/request */ "3b11");


/* 投放账户 - 分页查询 */
var searchPlacingAccPage = function searchPlacingAccPage() {
  for (var _len = arguments.length, params = new Array(_len), _key = 0; _key < _len; _key++) {
    params[_key] = arguments[_key];
  }
  return _request_request__WEBPACK_IMPORTED_MODULE_0__["post"].apply(void 0, ['/out/outside/placingAcc/searchPlacingAcc'].concat(params));
};

/* 查询项目列表信息 */
var getProjectList = function getProjectList() {
  for (var _len2 = arguments.length, params = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    params[_key2] = arguments[_key2];
  }
  return _request_request__WEBPACK_IMPORTED_MODULE_0__["post"].apply(void 0, ['/out/resource/project/getProjectList'].concat(params));
};
/* 查询项目信息列表 */
var getLeaderList = function getLeaderList() {
  for (var _len3 = arguments.length, params = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    params[_key3] = arguments[_key3];
  }
  return _request_request__WEBPACK_IMPORTED_MODULE_0__["post"].apply(void 0, ['/out/resource/project/getLeaderList'].concat(params));
};
/* 添加一条项目信息 */
var createProject = function createProject() {
  for (var _len4 = arguments.length, params = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
    params[_key4] = arguments[_key4];
  }
  return _request_request__WEBPACK_IMPORTED_MODULE_0__["post"].apply(void 0, ['/out/resource/project/createProject'].concat(params));
};
/* 查询单个项目信息 */
var getProject = function getProject() {
  for (var _len5 = arguments.length, params = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
    params[_key5] = arguments[_key5];
  }
  return _request_request__WEBPACK_IMPORTED_MODULE_0__["post"].apply(void 0, ['/out/resource/project/getProject'].concat(params));
};
/* 修改一条项目信息 */
var updProject = function updProject() {
  for (var _len6 = arguments.length, params = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
    params[_key6] = arguments[_key6];
  }
  return _request_request__WEBPACK_IMPORTED_MODULE_0__["post"].apply(void 0, ['/out/resource/project/updProject'].concat(params));
};
/* 关注/取消关注 */
var updProjectCare = function updProjectCare() {
  for (var _len7 = arguments.length, params = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
    params[_key7] = arguments[_key7];
  }
  return _request_request__WEBPACK_IMPORTED_MODULE_0__["post"].apply(void 0, ['/out/resource/project/updProjectCare'].concat(params));
};

/***/ }),

/***/ "5c11":
/*!************************************************************************************!*\
  !*** ./src/views/resource/project/project/formSearch.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_formSearch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./formSearch.vue?vue&type=script&lang=js& */ "4e8b");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_formSearch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "60c5d":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/resource/project/project/tableList.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function($) {/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "2f62");
/* harmony import */ var _config_ports__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./config/ports */ "5908");
/* harmony import */ var _newOrEditProjectDialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./newOrEditProjectDialog */ "ad35");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//


//
// 新建或编辑产品对话框组件

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    newOrEditProjectDialog: _newOrEditProjectDialog__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      currentPage: 1 /* 页码 */,
      total: 0 /* 总条目数 */,
      pageSizes: [30, 50, 100] /*, 每页显示个数选择器的选项设置 */,
      pageSize: 30 /* 每页展示的条数 */,

      //
      tableData: [],
      // 表格数据
      isShowAddFlg: false,
      isShowModifyFlg: false,
      isShowDelFlg: false,
      targets: [],
      container: null
    };
  },
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapState"])({
    formSearch: function formSearch(state) {
      return state.project.formSearch;
    },
    refreshTable: function refreshTable(state) {
      return state.project.refreshTable;
    }
  })),
  watch: {
    // 监听表单查询检索事件
    formSearch: function formSearch(newFlag, oldFlag) {
      //
      var vm = this;
      //重置页码
      vm.currentPage = 1;
      vm.pageSize = 30;
      // 获取表格数据
      vm.getProjectList();
    },
    refreshTable: {
      handler: function handler() {
        // 刷新表格数据
        this.getProjectList();
      },
      deep: true
    },
    tableData: {
      handler: function handler() {
        this.onRendered();
      }
    }
  },
  mounted: function mounted() {
    var vm = this;
    // 列表数据
    var fourLevelAuthList = vm.$store.state.currentUser.loginUserInfo.fourLevelAuthList;
    // 如果有数据，则判断是否有权限
    if (fourLevelAuthList.length > 0) {
      // 循环每一条权限数据
      for (var i = 0; i < fourLevelAuthList.length; i++) {
        // 获取每一条权限数据
        var eachFirstObj = fourLevelAuthList[i];
        // 新建
        if (eachFirstObj["fourAuthId"] === "A1_3_2_2_2") {
          vm.isShowAddFlg = true;
        }
        // 编辑
        if (eachFirstObj["fourAuthId"] === "A1_3_2_2_3") {
          vm.isShowModifyFlg = true;
        }
        // 删除
        if (eachFirstObj["fourAuthId"] === "A1_3_2_2_4") {
          vm.isShowDelFlg = true;
        }
      }
    }
  },
  methods: {
    getProjectList: function getProjectList() {
      //查询项目列表信息
      var vm = this;
      Object(_config_ports__WEBPACK_IMPORTED_MODULE_1__["getProjectList"])({
        projectNameOrLeaderName: vm.formSearch.projectNameOrLeaderName,
        pageNumber: vm.currentPage,
        pageSize: vm.pageSize
      }).then(function (res) {
        if (res.data.code == 0) {
          vm.tableData = res.data.objData.dataList;
          vm.total = parseInt(res.data.objData.dataCount);
        }
      });
    },
    openNewOrEditProjectDialog: function openNewOrEditProjectDialog(_ref) {
      var projectId = _ref.projectId;
      // 开启新建或编辑项目对话框 => projectId ? 编辑 : 新建

      this.$refs.newOrEditProjectDialog.open(projectId);

      //
      var vm = this;
      if (projectId) {
        //
        vm.$store.commit("project/currentEditProjectId", projectId);
      }
      //
      vm.$store.commit("project/dialog", "newOrEditProject");
    },
    delProject: function delProject(_ref2) {
      var projectId = _ref2.projectId;
      // 删除项目信息
      //
      var vm = this;
      vm.$confirm("是否确定提交此操作?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function () {
        Object(_config_ports__WEBPACK_IMPORTED_MODULE_1__["updProject"])({
          projectId: projectId,
          isDelFlg: '1'
        }).then(function (res) {
          vm.$message({
            type: res.data.status,
            message: res.data.message
          });
        });
      }).catch(function () {});
    },
    // ****************************************** EVENT ******************************************
    /**
     * 点击投放户数量时触发
     */
    onClickBindAccCount: function onClickBindAccCount(row) {
      var info = JSON.stringify({
        projectName: encodeURIComponent(row.projectName)
      });
      this.$open('/FrameWork/resource/account/placing?info=' + info);
    },
    /**
     * 点击关注事件
     */
    onClickFollow: function onClickFollow(row, isCare) {
      var vm = this;
      Object(_config_ports__WEBPACK_IMPORTED_MODULE_1__["updProjectCare"])({
        projectId: row.projectId,
        isCare: isCare
      }).then(function (ret) {
        vm.$message({
          message: '1' === isCare ? '关注成功！' : '取消关注成功！',
          type: 'success'
        });
        // 刷新表格数据
        vm.getProjectList();
      });
    },
    onRendered: function onRendered() {
      var vm = this;
      vm.$nextTick(function () {
        var _vm$$refs, _vm$$refs$table;
        vm.container = $('.nmg-view')[0];
        var el = (_vm$$refs = vm.$refs) === null || _vm$$refs === void 0 ? void 0 : (_vm$$refs$table = _vm$$refs.table) === null || _vm$$refs$table === void 0 ? void 0 : _vm$$refs$table.$el;
        if (el) {
          var headers = $(el).find('.el-table__header-wrapper');
          var fixedHeaders = $(el).find('.el-table__fixed-header-wrapper');
          vm.targets = [].concat(_toConsumableArray(headers), _toConsumableArray(fixedHeaders));
        }
      });
    }
  }
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! jquery */ "1157")))

/***/ }),

/***/ "64eb":
/*!******************************************************!*\
  !*** ./src/views/resource/project/project/index.vue ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _index_vue_vue_type_template_id_8654e95e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.vue?vue&type=template&id=8654e95e& */ "0463");
/* harmony import */ var _index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.vue?vue&type=script&lang=js& */ "cf32");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "0c7c");





/* normalize component */

var component = Object(_node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _index_vue_vue_type_template_id_8654e95e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _index_vue_vue_type_template_id_8654e95e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "65af":
/*!***********************************************************!*\
  !*** ./src/views/resource/project/project/formSearch.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _formSearch_vue_vue_type_template_id_4ba2b577___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./formSearch.vue?vue&type=template&id=4ba2b577& */ "cb9b");
/* harmony import */ var _formSearch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./formSearch.vue?vue&type=script&lang=js& */ "5c11");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "0c7c");





/* normalize component */

var component = Object(_node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _formSearch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _formSearch_vue_vue_type_template_id_4ba2b577___WEBPACK_IMPORTED_MODULE_0__["render"],
  _formSearch_vue_vue_type_template_id_4ba2b577___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "67c8":
/*!******************************************************************************************************!*\
  !*** ./src/views/resource/project/project/newOrEditProjectDialog.vue?vue&type=template&id=66d4b3f9& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_newOrEditProjectDialog_vue_vue_type_template_id_66d4b3f9___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./newOrEditProjectDialog.vue?vue&type=template&id=66d4b3f9& */ "7689");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_newOrEditProjectDialog_vue_vue_type_template_id_66d4b3f9___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_newOrEditProjectDialog_vue_vue_type_template_id_66d4b3f9___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "7689":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/resource/project/project/newOrEditProjectDialog.vue?vue&type=template&id=66d4b3f9& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('el-dialog', {
    staticClass: "view__resource__project__project__dialog",
    attrs: {
      "title": "项目信息",
      "visible": _vm.visible,
      "center": ""
    },
    on: {
      "update:visible": function updateVisible($event) {
        _vm.visible = $event;
      },
      "opened": _vm.onOpened,
      "closed": _vm.onClosed
    }
  }, [_c('el-form', {
    ref: "form",
    staticClass: "commonForm validateForm is-plain",
    attrs: {
      "model": _vm.form,
      "rules": _vm.rules,
      "label-width": "100px"
    }
  }, [_c('el-form-item', {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: false,
      expression: "false"
    }],
    attrs: {
      "prop": "projectId"
    }
  }, [_c('el-input', {
    model: {
      value: _vm.form.projectId,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "projectId", $$v);
      },
      expression: "form.projectId"
    }
  })], 1), _c('el-form-item', {
    attrs: {
      "label": "项目名称",
      "prop": "projectName"
    }
  }, [_c('el-input', {
    attrs: {
      "placeholder": "请输入项目名称"
    },
    model: {
      value: _vm.form.projectName,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "projectName", $$v);
      },
      expression: "form.projectName"
    }
  })], 1), _c('el-form-item', {
    attrs: {
      "label": "负责人",
      "prop": "leaderIds"
    }
  }, [_c('nmg-select', {
    staticClass: "remote-select",
    attrs: {
      "placeholder": "请选择负责人",
      "multiple": "",
      "filterable": "",
      "remote": "",
      "exhibition": ""
    },
    on: {
      "search": _vm.onSearchLeaderList
    },
    model: {
      value: _vm.form.leaderIds,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "leaderIds", $$v);
      },
      expression: "form.leaderIds"
    }
  }, [_vm._l(_vm._leaderOptsDefault, function (item, index) {
    return _c('nmg-option', {
      key: '_leaderOptsDefault' + index,
      attrs: {
        "label": item.realName + '(' + item.userName + ')',
        "value": item.userId
      }
    });
  }), _vm._l(_vm.leaderOpts, function (item2, index2) {
    return _c('nmg-option', {
      key: 'leaderOpts' + index2,
      attrs: {
        "label": item2.realName + '(' + item2.userName + ')',
        "value": item2.userId
      }
    });
  })], 2)], 1), !_vm.currentEditProjectId ? _c('el-form-item', {
    attrs: {
      "label": "投放账户",
      "prop": "placingAccountIds"
    }
  }, [_c('nmg-select', {
    attrs: {
      "complete": _vm.placingAccComplete,
      "multiple": "",
      "filterable": "",
      "remote": "",
      "exhibition": ""
    },
    on: {
      "load": _vm.onLoadPlacingAccountIds,
      "search": _vm.onSearchPlacingAccountIds
    },
    model: {
      value: _vm.form.placingAccountIds,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "placingAccountIds", $$v);
      },
      expression: "form.placingAccountIds"
    }
  }, _vm._l(_vm.placingAccountIdsOptions, function (item, index) {
    return _c('nmg-option', {
      key: index,
      attrs: {
        "label": '[' + item['mediaPlacingAccIdInput'] + '] - ' + item.mediaCustName,
        "value": item.placingAccountId
      }
    });
  }), 1)], 1) : _vm._e()], 1), _c('div', {
    staticClass: "dialog-footer",
    attrs: {
      "slot": "footer"
    },
    slot: "footer"
  }, [_c('el-button', {
    attrs: {
      "round": "",
      "type": "primary"
    },
    on: {
      "click": _vm.subForm
    }
  }, [_vm._v(" 保 存 ")]), _c('el-button', {
    attrs: {
      "round": ""
    },
    on: {
      "click": function click($event) {
        _vm.visible = false;
      }
    }
  }, [_vm._v(" 取 消 ")])], 1)], 1);
};
var staticRenderFns = [];


/***/ }),

/***/ "7b906":
/*!**********************************************************!*\
  !*** ./src/views/resource/project/project/tableList.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tableList_vue_vue_type_template_id_b44db39e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tableList.vue?vue&type=template&id=b44db39e& */ "1afc");
/* harmony import */ var _tableList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tableList.vue?vue&type=script&lang=js& */ "4e36");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "0c7c");





/* normalize component */

var component = Object(_node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _tableList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _tableList_vue_vue_type_template_id_b44db39e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _tableList_vue_vue_type_template_id_b44db39e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "7dae3":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/resource/project/project/tableList.vue?vue&type=template&id=b44db39e& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', [_c('nmg-sticky', {
    attrs: {
      "container": _vm.container,
      "targets": _vm.targets,
      "offset-top": 60
    }
  }, [_c('nmg-table', {
    ref: "table",
    attrs: {
      "title": "项目列表",
      "data": _vm.tableData,
      "current-page": _vm.currentPage,
      "total": _vm.total,
      "page-size": _vm.pageSize
    },
    on: {
      "update:currentPage": function updateCurrentPage($event) {
        _vm.currentPage = $event;
      },
      "update:current-page": function updateCurrentPage($event) {
        _vm.currentPage = $event;
      },
      "update:pageSize": function updatePageSize($event) {
        _vm.pageSize = $event;
      },
      "update:page-size": function updatePageSize($event) {
        _vm.pageSize = $event;
      },
      "size-change": _vm.getProjectList,
      "current-change": _vm.getProjectList
    },
    scopedSlots: _vm._u([{
      key: "titleHandler",
      fn: function fn() {
        return [_vm.isShowAddFlg ? _c('el-button', {
          attrs: {
            "type": "primary",
            "plain": "",
            "round": "",
            "icon": "el-icon-plus"
          },
          on: {
            "click": _vm.openNewOrEditProjectDialog
          }
        }, [_vm._v("新建项目")]) : _vm._e()];
      },
      proxy: true
    }])
  }, [_c('el-table-column', {
    attrs: {
      "label": "项目名称",
      "prop": "projectName"
    }
  }), _c('el-table-column', {
    attrs: {
      "label": "负责人",
      "prop": "leaderName"
    }
  }), _c('el-table-column', {
    attrs: {
      "label": "投放户数量",
      "prop": "bindAccCount"
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(scope) {
        return [_c('el-button', {
          attrs: {
            "type": "text"
          },
          on: {
            "click": function click($event) {
              return _vm.onClickBindAccCount(scope.row);
            }
          }
        }, [_vm._v(_vm._s(scope.row.bindAccCount) + " ")])];
      }
    }])
  }), _c('el-table-column', {
    attrs: {
      "label": "创建时间",
      "prop": "createDate"
    }
  }), _vm.isShowModifyFlg || _vm.isShowDelFlg ? _c('el-table-column', {
    attrs: {
      "label": "操作"
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(scope) {
        return ['0' === scope.row.isCare ? _c('el-button', {
          attrs: {
            "type": "text"
          },
          on: {
            "click": function click($event) {
              return _vm.onClickFollow(scope.row, '1');
            }
          }
        }, [_vm._v("关注 ")]) : '1' === scope.row.isCare ? _c('el-button', {
          attrs: {
            "type": "text"
          },
          on: {
            "click": function click($event) {
              return _vm.onClickFollow(scope.row, '0');
            }
          }
        }, [_vm._v("取消关注 ")]) : _vm._e(), _vm.isShowModifyFlg ? _c('el-button', {
          attrs: {
            "type": "text"
          },
          on: {
            "click": function click($event) {
              return _vm.openNewOrEditProjectDialog(scope.row);
            }
          }
        }, [_vm._v("编辑")]) : _vm._e(), _vm.isShowDelFlg ? _c('el-button', {
          attrs: {
            "type": "text"
          },
          on: {
            "click": function click($event) {
              return _vm.delProject(scope.row);
            }
          }
        }, [_vm._v("删除")]) : _vm._e()];
      }
    }], null, false, 2893108015)
  }) : _vm._e()], 1)], 1), _c('new-or-edit-project-dialog', {
    ref: "newOrEditProjectDialog"
  })], 1);
};
var staticRenderFns = [];


/***/ }),

/***/ "8b30":
/*!***********************************************************!*\
  !*** ./src/views/resource/project/project/config/data.js ***!
  \***********************************************************/
/*! exports provided: form, rules, searchForm */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "form", function() { return form; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rules", function() { return rules; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchForm", function() { return searchForm; });
var form = {
  projectId: null,
  // 项目ID => 编辑时进行使用
  projectName: null,
  leaderIds: [],
  // 投放账户
  placingAccountIds: []
};
var rules = {
  projectName: [{
    required: true,
    message: "项目名称不能为空",
    trigger: "blur"
  }, {
    // 匹配长度 -- 不超过20个字符
    validator: function validator(rule, value, callback) {
      if (value.length > 20) {
        callback("长度不超过20个字符");
      } else {
        callback();
      }
    },
    trigger: "blur"
  }, {
    // 匹配输入内容 -- 只支持输入汉字、字母、数字及下划线
    validator: function validator(rule, value, callback) {
      //
      var illegalChar = /[^a-zA-Z0-9\u4E00-\u9FA5_]/g;
      if (illegalChar.test(value)) {
        callback("只支持输入汉字、字母、数字及下划线");
      } else {
        callback();
      }
    },
    trigger: "blur"
  }],
  placingAccountIds: [{
    required: true,
    message: "请选择投放账户",
    trigger: "change"
  }]
};
var searchForm = {
  projectNameOrLeaderName: null
};

/***/ }),

/***/ "abc6":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/resource/project/project/index.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _formSearch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./formSearch */ "65af");
/* harmony import */ var _tableList__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tableList */ "7b906");
/* harmony import */ var _config_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config/store */ "efdb");
// 查询条件组件

// 列表组件


//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'project',
  components: {
    "form-search": _formSearch__WEBPACK_IMPORTED_MODULE_0__["default"],
    "table-list": _tableList__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  beforeCreate: function beforeCreate() {
    if (this.$store.hasModule(this.$options.name)) {
      this.$store.unregisterModule(this.$options.name);
    }
    this.$store.registerModule(this.$options.name, this.$deepCopy(_config_store__WEBPACK_IMPORTED_MODULE_2__["default"]));
  }
});

/***/ }),

/***/ "ad35":
/*!***********************************************************************!*\
  !*** ./src/views/resource/project/project/newOrEditProjectDialog.vue ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _newOrEditProjectDialog_vue_vue_type_template_id_66d4b3f9___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./newOrEditProjectDialog.vue?vue&type=template&id=66d4b3f9& */ "67c8");
/* harmony import */ var _newOrEditProjectDialog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./newOrEditProjectDialog.vue?vue&type=script&lang=js& */ "f3be");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "0c7c");





/* normalize component */

var component = Object(_node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _newOrEditProjectDialog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _newOrEditProjectDialog_vue_vue_type_template_id_66d4b3f9___WEBPACK_IMPORTED_MODULE_0__["render"],
  _newOrEditProjectDialog_vue_vue_type_template_id_66d4b3f9___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "bd2a":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/resource/project/project/formSearch.vue?vue&type=template&id=4ba2b577& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('nmg-form', {
    ref: "form",
    staticClass: "--tool-shadow-box",
    attrs: {
      "inline": true,
      "defaultForm": _vm.defaultForm,
      "resetable": "",
      "searchable": ""
    },
    on: {
      "search": _vm.search
    },
    model: {
      value: _vm.form,
      callback: function callback($$v) {
        _vm.form = $$v;
      },
      expression: "form"
    }
  }, [_c('nmg-form-item', {
    attrs: {
      "prop": "projectNameOrLeaderName",
      "label": "项目/负责人"
    }
  }, [_c('nmg-input', {
    staticStyle: {
      "width": "200px"
    },
    attrs: {
      "trim": "",
      "placeholder": "请输入项目/负责人关键字"
    },
    model: {
      value: _vm.form.projectNameOrLeaderName,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "projectNameOrLeaderName", $$v);
      },
      expression: "form.projectNameOrLeaderName"
    }
  })], 1)], 1);
};
var staticRenderFns = [];


/***/ }),

/***/ "c299":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/resource/project/project/newOrEditProjectDialog.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "2f62");
/* harmony import */ var _config_ports__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./config/ports */ "5908");
/* harmony import */ var _config_data_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config/data.js */ "8b30");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) keys.push(key); return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
//




//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      name: "newOrEditProject",
      currentUser: this.$localStorage.getItem("currentUser"),
      // 当前都登录用户
      leaderOpts: [],
      // 负责人下拉选项列表
      leaderOptsDefault: [],
      // 负责人下拉选项列表
      form: this.$deepCopy(_config_data_js__WEBPACK_IMPORTED_MODULE_2__["form"]),
      rules: _config_data_js__WEBPACK_IMPORTED_MODULE_2__["rules"],
      // 投放户备选项页索引
      placingAccPageIndex: 1,
      // 投放户备选项页容量
      placingAccPageSize: 100,
      // 投放户备选项
      placingAccountIdsOptions: [],
      // 投放户是否完成
      placingAccComplete: false,
      visible: false,
      // 项目标识
      currentEditProjectId: ''
    };
  },
  computed: {
    _leaderOptsDefault: function _leaderOptsDefault() {
      var vm = this;
      var value = vm.leaderOptsDefault.filter(function (item) {
        return !vm.leaderOpts.some(function (item2) {
          return item.userId === item2.userId;
        });
      });
      return value;
    }
  },
  methods: {
    open: function open(currentEditProjectId) {
      this.visible = true;
      this.currentEditProjectId = currentEditProjectId;
    },
    /**
     * 查询投放户信息
     */
    searchPlacingAccPage: function searchPlacingAccPage(advertiserName) {
      var vm = this;
      var params = {
        userId: vm.currentUser.loginUserInfo.roleId,
        userType: vm.currentUser.loginUserInfo.userType,
        pageNumber: vm.placingAccPageIndex,
        // 页码
        pageSize: vm.placingAccPageSize // 每页展示的条数
      };

      if (advertiserName) {
        params.placingAccIdOrPlacingAccName = advertiserName;
      }
      Object(_config_ports__WEBPACK_IMPORTED_MODULE_1__["searchPlacingAccPage"])(params).then(function (ret) {
        if (1 === vm.placingAccPageIndex) {
          vm.placingAccountIdsOptions = ret.data.objData.dataList || [];
        } else {
          var _vm$placingAccountIds;
          vm.placingAccountIdsOptions = (_vm$placingAccountIds = vm.placingAccountIdsOptions).concat.apply(_vm$placingAccountIds, _toConsumableArray(ret.data.objData.dataList || []));
        }
        vm.placingAccPageIndex++;
        if ((ret.data.objData.dataList || []).length < vm.placingAccPageSize) {
          vm.placingAccComplete = true;
        } else {
          vm.placingAccComplete = false;
        }
      });
    },
    /**
     * 获取负责人列表
     */
    getLeaderList: function getLeaderList(_userIds, _realName) {
      var searchForm = {
        pageNumber: 1,
        pageSize: 1000
      };
      if (_userIds) {
        searchForm.userIds = _userIds;
      }
      if (_realName) {
        searchForm.realName = _realName;
      }
      return Object(_config_ports__WEBPACK_IMPORTED_MODULE_1__["getLeaderList"])(searchForm);
    },
    subForm: function subForm() {
      // 提交表单 => vm.form.projectId ? 编辑操作 : 新增操作
      //
      var vm = this;
      vm.$refs["form"].validate(function (valid) {
        if (valid) {
          vm.$confirm("是否确定提交此操作?", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }).then(function () {
            //
            if (vm.form.projectId) {
              // 修改操作
              Object(_config_ports__WEBPACK_IMPORTED_MODULE_1__["updProject"])({
                projectId: vm.form.projectId,
                projectName: vm.form.projectName,
                leaderIds: vm.form.leaderIds
              }).then(function (res) {
                vm.$message({
                  type: res.data.status,
                  message: res.data.message
                });
                //
                // 刷新表格
                vm.$store.commit("project/refreshTable", {});
                vm.visible = false;
              });
            } else {
              // 新增操作
              Object(_config_ports__WEBPACK_IMPORTED_MODULE_1__["createProject"])({
                projectName: vm.form.projectName,
                leaderIds: vm.form.leaderIds,
                placingAccountIds: vm.form.placingAccountIds
              }).then(function (res) {
                vm.$message({
                  type: res.data.status,
                  message: res.data.message
                });
                //
                // 刷新表格
                vm.$store.commit("project/refreshTable", {});
                vm.visible = false;
              });
            }
          }).catch(function () {});
        }
      });
    },
    // *********************************** EVENT ***********************************
    onOpened: function onOpened() {
      var _this = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var vm, projectRet, leaderListRet;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              //
              vm = _this; // 获取负责人列表
              _context.next = 3;
              return vm.getLeaderList().then(function (ret) {
                vm.leaderOpts = ret.data.objData.dataList;
              });
            case 3:
              if (!vm.currentEditProjectId) {
                _context.next = 17;
                break;
              }
              _context.next = 6;
              return Object(_config_ports__WEBPACK_IMPORTED_MODULE_1__["getProject"])({
                projectId: vm.currentEditProjectId
              });
            case 6:
              projectRet = _context.sent;
              vm.form.projectId = projectRet.data.objData.projectId;
              vm.form.projectName = projectRet.data.objData.projectName;

              // 防止匹配不到负责人情况
              if (!projectRet.data.objData.leaderIds) {
                _context.next = 15;
                break;
              }
              _context.next = 12;
              return vm.getLeaderList(projectRet.data.objData.leaderIds, null);
            case 12:
              leaderListRet = _context.sent;
              vm.leaderOptsDefault = leaderListRet.data.objData.dataList;
              vm.form.leaderIds = projectRet.data.objData.leaderIds;
            case 15:
              _context.next = 18;
              break;
            case 17:
              // 新建
              // 查询投放户信息
              vm.searchPlacingAccPage();
            case 18:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }))();
    },
    onClosed: function onClosed() {
      //
      var vm = this;
      // 重置数据
      vm.leaderOpts = [];
      vm.leaderOptsDefault = [];
      vm.form = this.$deepCopy(_config_data_js__WEBPACK_IMPORTED_MODULE_2__["form"]);
      vm.rules = _config_data_js__WEBPACK_IMPORTED_MODULE_2__["rules"];
      vm.placingAccPageIndex = 1;
      // 投放户备选项
      vm.placingAccountIdsOptions = [];
      // 投放户是否完成
      vm.placingAccComplete = false;
      // 项目标识
      vm.currentEditProjectId = '';
      // 重置当前对话框表单
      vm.$refs["form"].resetFields();
    },
    onLoadPlacingAccountIds: function onLoadPlacingAccountIds(val) {
      this.searchPlacingAccPage(val);
    },
    onSearchPlacingAccountIds: function onSearchPlacingAccountIds(val) {
      this.placingAccPageIndex = 1;
      this.searchPlacingAccPage(val);
    },
    onSearchLeaderList: function onSearchLeaderList(val) {
      var vm = this;
      this.getLeaderList(null, val).then(function (ret) {
        vm.leaderOpts = ret.data.objData.dataList;
      });
    }
  }
});

/***/ }),

/***/ "c964":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/resource/project/project/index.vue?vue&type=template&id=8654e95e& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', [_c('form-search'), _c('table-list')], 1);
};
var staticRenderFns = [];


/***/ }),

/***/ "cb9b":
/*!******************************************************************************************!*\
  !*** ./src/views/resource/project/project/formSearch.vue?vue&type=template&id=4ba2b577& ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_formSearch_vue_vue_type_template_id_4ba2b577___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./formSearch.vue?vue&type=template&id=4ba2b577& */ "bd2a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_formSearch_vue_vue_type_template_id_4ba2b577___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_formSearch_vue_vue_type_template_id_4ba2b577___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "cf32":
/*!*******************************************************************************!*\
  !*** ./src/views/resource/project/project/index.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./index.vue?vue&type=script&lang=js& */ "abc6");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "efdb":
/*!************************************************************!*\
  !*** ./src/views/resource/project/project/config/store.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// 项目
/* harmony default export */ __webpack_exports__["default"] = ({
  namespaced: true,
  // 命名空间
  state: {
    formSearch: {
      projectNameOrLeaderName: null
    },
    dialog: null,
    currentEditProjectId: null,
    // 当前在编辑的项目ID
    // 刷新表格数据
    refreshTable: null
  },
  getters: {},
  mutations: {
    dialog: function dialog(state, data) {
      state.dialog = data;
    },
    formSearch: function formSearch(state, data) {
      state.formSearch = data;
    },
    currentEditProjectId: function currentEditProjectId(state, data) {
      state.currentEditProjectId = data;
    },
    refreshTable: function refreshTable(state, data) {
      state.refreshTable = data;
    }
  }
});

/***/ }),

/***/ "f3be":
/*!************************************************************************************************!*\
  !*** ./src/views/resource/project/project/newOrEditProjectDialog.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_newOrEditProjectDialog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./newOrEditProjectDialog.vue?vue&type=script&lang=js& */ "c299");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_newOrEditProjectDialog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ })

}]);