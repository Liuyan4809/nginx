(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["chunk-59382daa"],{

/***/ "197e":
/*!***************************************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/materialClaim.vue?vue&type=template&id=71cbe771& ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_materialClaim_vue_vue_type_template_id_71cbe771___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./materialClaim.vue?vue&type=template&id=71cbe771& */ "7579");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_materialClaim_vue_vue_type_template_id_71cbe771___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_materialClaim_vue_vue_type_template_id_71cbe771___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "2687":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@vue/cli-service/node_modules/mini-css-extract-plugin/dist/loader.js??ref--9-oneOf-1-0!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/system/auxiliary/materialClaim/materialClaim.vue?vue&type=style&index=0&id=71cbe771&prod&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "36b5":
/*!****************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/searchForm/searchForm.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _searchForm_vue_vue_type_template_id_542c65d2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./searchForm.vue?vue&type=template&id=542c65d2& */ "3ba5");
/* harmony import */ var _searchForm_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./searchForm.vue?vue&type=script&lang=js& */ "8153");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "0c7c");





/* normalize component */

var component = Object(_node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _searchForm_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _searchForm_vue_vue_type_template_id_542c65d2___WEBPACK_IMPORTED_MODULE_0__["render"],
  _searchForm_vue_vue_type_template_id_542c65d2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "3ba5":
/*!***********************************************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/searchForm/searchForm.vue?vue&type=template&id=542c65d2& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_searchForm_vue_vue_type_template_id_542c65d2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!../../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../../node_modules/babel-loader/lib!../../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!../../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./searchForm.vue?vue&type=template&id=542c65d2& */ "8fe9");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_searchForm_vue_vue_type_template_id_542c65d2___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_searchForm_vue_vue_type_template_id_542c65d2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "4423":
/*!******************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/config/store.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tools_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/tools/common */ "0014");
/* harmony import */ var _searchForm_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../searchForm/data */ "af15");


/* harmony default export */ __webpack_exports__["default"] = ({
  namespaced: true,
  state: {
    activeName: '1',
    // 搜索表单
    searchFormData: Object(_tools_common__WEBPACK_IMPORTED_MODULE_0__["deepCopy"])(_searchForm_data__WEBPACK_IMPORTED_MODULE_1__["searchFormData"]),
    // 主动刷新表格数据
    isRefresh: ''
  },
  getters: {},
  actions: {},
  mutations: {
    activeName: function activeName(state, data) {
      state.activeName = data;
    },
    searchFormData: function searchFormData(state, data) {
      state.searchFormData = data;
    },
    isRefresh: function isRefresh(state, data) {
      state.isRefresh = data;
    }
  }
});

/***/ }),

/***/ "44f2":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/system/auxiliary/materialClaim/dialogBatchDistribution/dialogBatchDistribution.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data */ "a317");
/* harmony import */ var _ports__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ports */ "c801");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vuex */ "2f62");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }




/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // 表单数据
      form: this.$deepCopy(_data__WEBPACK_IMPORTED_MODULE_0__["form"]),
      // 重置时使用的默认表单
      defaultForm: this.$deepCopy(_data__WEBPACK_IMPORTED_MODULE_0__["form"]),
      // 校验规则
      rules: this.$deepCopy(_data__WEBPACK_IMPORTED_MODULE_0__["rules"]),
      // 是否可见
      visible: false,
      rows: [],
      authorUserList: [],
      materialInfo: null
    };
  },
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_2__["mapState"])({
    activeName: function activeName(state) {
      return state.materialClaim.activeName;
    }
  })),
  methods: {
    /**
     * public
     * 打开弹窗 
     */
    open: function open(rows) {
      var vm = this;
      this.visible = true;
      this.rows = rows;
      this.materialInfo = this.rows.map(function (item) {
        return "".concat(item.materialId, "\u3010").concat(item.materialName, "\u3011");
      }).join('，');
      // 查询素材库作者下拉列表数据
      Object(_ports__WEBPACK_IMPORTED_MODULE_1__["doSearchMaterialAuthorForSelect"])().then(function (res) {
        vm.authorUserList = res.data.listData;
      });
    },
    /**
     * 保存数据
     */
    save: function save() {
      var vm = this;
      vm.$refs['form'].validate(function (valid) {
        if (valid) {
          var params = vm.$deepCopy(vm.form);
          params.mediaType = vm.activeName;
          params.materialType = vm.rows[0].materialType;
          params.materialId = vm.rows.map(function (item) {
            return item.materialId;
          }).join(',');
          Object(_ports__WEBPACK_IMPORTED_MODULE_1__["material"])(params).then(function (ret) {
            vm.$message({
              type: "success",
              message: ret.data.message
            });
          });
          // 主动刷新表格数据
          vm.$store.commit("materialClaim/isRefresh", {});
          vm.visible = false;
        } else {
          return false;
        }
      });
    },
    onClose: function onClose() {
      Object.assign(this.$data, this.$options.data.call(this));
      this.$refs.form.clearValidate();
    }
  }
});

/***/ }),

/***/ "5269":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/system/auxiliary/materialClaim/searchForm/searchForm.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data */ "af15");
/* harmony import */ var _config_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../config/data */ "d9b4");
/* harmony import */ var _tools_date__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/tools/date */ "fd23");



var now = new Date();
var year = now.getFullYear();
var month = now.getMonth();
var day = now.getDate();
var lastMonthMinTime = new Date(year + '-' + month + '-' + 1).getTime();
var thisMonthMinTime = Object(_tools_date__WEBPACK_IMPORTED_MODULE_2__["getDayOfMonth"])(now, 1).getTime();
var thisMonthMaxTime = Object(_tools_date__WEBPACK_IMPORTED_MODULE_2__["getDayOfMonth"])(now, 0).getTime();
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // 表单
      form: this.$deepCopy(_data__WEBPACK_IMPORTED_MODULE_0__["searchFormData"]),
      // 重置时使用的默认表单
      defaultForm: this.$deepCopy(_data__WEBPACK_IMPORTED_MODULE_0__["searchFormData"]),
      // 地址栏携带的信息
      info: JSON.parse(this.$route.query.info || "{}"),
      materialType: _config_data__WEBPACK_IMPORTED_MODULE_1__["materialType"],
      datePickerOptions: {
        disabledDate: function disabledDate(date) {
          var dateTime = date.getTime();
          if (dateTime > thisMonthMaxTime) return true;
          // 每月8号（包括8号）之前可以查询上个月和本月数据，8号之后只能查询本月数据
          // 查上个月和本月
          if (day <= 8) {
            if (dateTime < lastMonthMinTime) return true;
          }
          // 查本月
          else {
            if (dateTime < thisMonthMinTime) return true;
          }
        }
      }
    };
  },
  methods: {
    // ************************************************ EVENT ************************************************
    /**
     * 查询
     */
    onSearch: function onSearch() {
      this.$store.commit("materialClaim/searchFormData", this.$deepCopy(this.form));
    }
  },
  created: function created() {
    var vm = this;
    // 可有在此动态设置默认的查询参数 
    // 默认查询一次
    vm.onSearch();
  }
});

/***/ }),

/***/ "7579":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/system/auxiliary/materialClaim/materialClaim.vue?vue&type=template&id=71cbe771& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "system__auxiliary__materialClaim"
  }, [_c('form-search'), _c('nmg-sticky', {
    attrs: {
      "container": _vm.container,
      "targets": _vm.targets,
      "offset-top": 60
    }
  }, [_c('nmg-table', {
    ref: "table",
    attrs: {
      "immediate": false,
      "title": "素材认领列表",
      "url": "/statistics/ad/platform/statistics/materialClaim/query/material",
      "requestType": "post",
      "params": _vm.params,
      "paramConfig": _vm.paramConfig,
      "default-sort": _vm.defaultSort,
      "responseConfig": _vm.responseConfig,
      "columns": _vm.columns,
      "show-summary": true,
      "summary-method": _vm.getSummaries
    },
    on: {
      "selection-change": _vm.onSelectionChange,
      "loaded": _vm.onLoaded
    },
    scopedSlots: _vm._u([{
      key: "title",
      fn: function fn(scope) {
        return [_c('span', {
          staticStyle: {
            "margin-right": "40px"
          }
        }, [_vm._v("素材认领列表")]), _c('span', {
          staticStyle: {
            "color": "#8b8b8b"
          }
        }, [_vm._v("此列表统计上月1日至昨日时间范围内，总消耗大于100元的未归因自产素材、衍生素材")])];
      }
    }, {
      key: "titleHandler",
      fn: function fn(scope) {
        return [_c('el-button', {
          attrs: {
            "type": "primary",
            "disabled": !_vm.selection.length,
            "plain": "",
            "round": "",
            "size": "small"
          },
          on: {
            "click": function click($event) {
              return _vm.onClickBatchDistribution(_vm.selection);
            }
          }
        }, [_vm._v("批量分配")])];
      }
    }, {
      key: "materialUrl",
      fn: function fn(_ref) {
        var row = _ref.row;
        return ['1' === _vm.searchFormData.materialType ? _c('nmg-video', {
          staticClass: "ul__material",
          attrs: {
            "disabledDefaultPlay": true,
            "previewType": "click",
            "src": '2' === _vm.activeName ? row._materialUrl : row.materialUrl,
            "poster": '2' === _vm.activeName ? row.materialUrl : null,
            "previewTitle": "预览素材"
          },
          nativeOn: {
            "click": function click($event) {
              return _vm.onClickMaterialUrlVideo(row);
            }
          }
        }) : _c('nmg-img', {
          staticClass: "ul__material",
          attrs: {
            "alt": "素材",
            "src": row.materialUrl
          }
        })];
      }
    }, {
      key: "placingAccountId",
      fn: function fn(_ref2) {
        var row = _ref2.row;
        return [_vm._v(" " + _vm._s(row.placingAccountId || '')), _c('br'), row.mediaCustName ? _c('span', [_vm._v(_vm._s("\u3010".concat(row.mediaCustName, "\u3011")))]) : _vm._e()];
      }
    }, {
      key: "materialType",
      fn: function fn(_ref3) {
        var row = _ref3.row;
        return [_vm._v(" " + _vm._s(_vm.materialType[row.materialType]) + " ")];
      }
    }, {
      key: "statDate",
      fn: function fn(_ref4) {
        var row = _ref4.row;
        return [_vm._v(" " + _vm._s(row.statDate ? _vm.$date2String(new Date(row.statDate), 'yyyy-MM-dd') : null) + " ")];
      }
    }, {
      key: "operation",
      fn: function fn(_ref5) {
        var row = _ref5.row;
        return [_c('el-button', {
          attrs: {
            "type": "text",
            "size": "small"
          },
          on: {
            "click": function click($event) {
              return _vm.onClickBatchDistribution([row]);
            }
          }
        }, [_vm._v("分配")])];
      }
    }])
  })], 1), _c('dialogBatchDistribution', {
    ref: "dialogBatchDistribution"
  })], 1);
};
var staticRenderFns = [];


/***/ }),

/***/ "8153":
/*!*****************************************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/searchForm/searchForm.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_searchForm_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../../node_modules/babel-loader/lib!../../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./searchForm.vue?vue&type=script&lang=js& */ "5269");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_searchForm_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "8fe9":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/system/auxiliary/materialClaim/searchForm/searchForm.vue?vue&type=template&id=542c65d2& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('nmg-form', {
    ref: "form",
    staticClass: "--tool-shadow-box",
    attrs: {
      "inline": true,
      "default-form": _vm.defaultForm,
      "searchable": "",
      "resetable": ""
    },
    on: {
      "search": _vm.onSearch
    },
    model: {
      value: _vm.form,
      callback: function callback($$v) {
        _vm.form = $$v;
      },
      expression: "form"
    }
  }, [_c('nmg-form-item', {
    attrs: {
      "label": "产品",
      "prop": "productName"
    }
  }, [_c('nmg-input', {
    attrs: {
      "placeholder": "请输入产品名称",
      "clearable": ""
    },
    model: {
      value: _vm.form.productName,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "productName", $$v);
      },
      expression: "form.productName"
    }
  })], 1), _c('nmg-form-item', {
    attrs: {
      "label": "素材名称",
      "prop": "materialName"
    }
  }, [_c('nmg-input', {
    attrs: {
      "placeholder": "请输入素材名称",
      "clearable": ""
    },
    model: {
      value: _vm.form.materialName,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "materialName", $$v);
      },
      expression: "form.materialName"
    }
  })], 1), _c('nmg-form-item', {
    attrs: {
      "label": "素材类型",
      "prop": "materialType",
      "placeholder": "请选择素材类型"
    }
  }, [_c('nmg-select', {
    model: {
      value: _vm.form.materialType,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "materialType", $$v);
      },
      expression: "form.materialType"
    }
  }, _vm._l(_vm.materialType, function (item, i) {
    return _c('nmg-option', {
      key: i,
      attrs: {
        "value": i,
        "label": item
      }
    });
  }), 1)], 1), _c('nmg-form-item', {
    attrs: {
      "label": "投放账户",
      "prop": "placingAccountId"
    }
  }, [_c('nmg-input', {
    attrs: {
      "placeholder": "请输入投放账户ID/投放账户名称",
      "clearable": ""
    },
    model: {
      value: _vm.form.placingAccountId,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "placingAccountId", $$v);
      },
      expression: "form.placingAccountId"
    }
  })], 1), _c('nmg-form-item', {
    attrs: {
      "label": "素材ID",
      "prop": "materialId"
    }
  }, [_c('nmg-input', {
    attrs: {
      "placeholder": "请输入素材ID",
      "clearable": ""
    },
    model: {
      value: _vm.form.materialId,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "materialId", $$v);
      },
      expression: "form.materialId"
    }
  })], 1)], 1);
};
var staticRenderFns = [];


/***/ }),

/***/ "93f6":
/*!***********************************************************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/materialClaim.vue?vue&type=style&index=0&id=71cbe771&prod&lang=scss& ***!
  \***********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_cli_service_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_vue_cli_service_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_materialClaim_vue_vue_type_style_index_0_id_71cbe771_prod_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/@vue/cli-service/node_modules/mini-css-extract-plugin/dist/loader.js??ref--9-oneOf-1-0!../../../../../node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./materialClaim.vue?vue&type=style&index=0&id=71cbe771&prod&lang=scss& */ "2687");
/* harmony import */ var _node_modules_vue_cli_service_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_vue_cli_service_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_materialClaim_vue_vue_type_style_index_0_id_71cbe771_prod_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_cli_service_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_vue_cli_service_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_materialClaim_vue_vue_type_style_index_0_id_71cbe771_prod_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_cli_service_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_vue_cli_service_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_materialClaim_vue_vue_type_style_index_0_id_71cbe771_prod_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_cli_service_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_vue_cli_service_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_materialClaim_vue_vue_type_style_index_0_id_71cbe771_prod_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "a317":
/*!**********************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/dialogBatchDistribution/data.js ***!
  \**********************************************************************************/
/*! exports provided: form, rules */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "form", function() { return form; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rules", function() { return rules; });
// 主表单
var form = {
  // 拍摄
  shootUserId: null,
  // 编导
  directorUserId: null,
  // 后期
  materialAuthorId: null
};
var rules = {
  // shootUserId: [
  //     {required: true, message: '请选择拍摄人员', trigger: 'change' }
  // ],
  // directorUserId: [
  //     {required: true, message: '请选择编导人员', trigger: 'change' }
  // ],
  materialAuthorId: [{
    required: true,
    message: '请选择后期人员',
    trigger: 'change'
  }]
};

/***/ }),

/***/ "af15":
/*!*********************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/searchForm/data.js ***!
  \*********************************************************************/
/*! exports provided: searchFormData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchFormData", function() { return searchFormData; });
var searchFormData = {
  // 产品
  productName: null,
  // 素材名称
  materialName: null,
  // 素材ID
  materialId: null,
  // 投放账户
  placingAccountId: null,
  // 素材类型
  materialType: '1'
};

/***/ }),

/***/ "b582":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/system/auxiliary/materialClaim/dialogBatchDistribution/dialogBatchDistribution.vue?vue&type=template&id=17848e4d& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('el-dialog', {
    attrs: {
      "title": "素材作者分配",
      "visible": _vm.visible,
      "center": "",
      "width": "900px",
      "destroy-on-close": true,
      "close-on-press-escape": true,
      "close-on-click-modal": false
    },
    on: {
      "update:visible": function updateVisible($event) {
        _vm.visible = $event;
      },
      "close": _vm.onClose
    }
  }, [_c('nmg-form', {
    ref: "form",
    staticClass: "commonForm validateForm",
    attrs: {
      "default-form": _vm.defaultForm,
      "rules": _vm.rules,
      "label-width": "120px"
    },
    model: {
      value: _vm.form,
      callback: function callback($$v) {
        _vm.form = $$v;
      },
      expression: "form"
    }
  }, [_c('el-form-item', {
    attrs: {
      "label": "拍摄",
      "prop": "shootUserId"
    }
  }, [_c('el-select', {
    attrs: {
      "filterable": "",
      "clearable": "",
      "placeholder": "请选择拍摄人员"
    },
    model: {
      value: _vm.form.shootUserId,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "shootUserId", $$v);
      },
      expression: "form.shootUserId"
    }
  }, _vm._l(_vm.authorUserList, function (item, index) {
    return _c('el-option', {
      key: index,
      attrs: {
        "value": item.userId,
        "label": item.userName
      }
    }, [_vm._v(_vm._s(item.userName) + " ")]);
  }), 1)], 1), _c('el-form-item', {
    attrs: {
      "label": "编导",
      "prop": "directorUserId"
    }
  }, [_c('el-select', {
    attrs: {
      "filterable": "",
      "clearable": "",
      "placeholder": "请选择编导人员"
    },
    model: {
      value: _vm.form.directorUserId,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "directorUserId", $$v);
      },
      expression: "form.directorUserId"
    }
  }, _vm._l(_vm.authorUserList, function (item, index) {
    return _c('el-option', {
      key: index,
      attrs: {
        "value": item.userId,
        "label": item.userName
      }
    }, [_vm._v(_vm._s(item.userName) + " ")]);
  }), 1)], 1), _c('el-form-item', {
    attrs: {
      "label": "后期",
      "prop": "materialAuthorId"
    }
  }, [_c('el-select', {
    attrs: {
      "filterable": "",
      "clearable": "",
      "placeholder": "请选择后期人员"
    },
    model: {
      value: _vm.form.materialAuthorId,
      callback: function callback($$v) {
        _vm.$set(_vm.form, "materialAuthorId", $$v);
      },
      expression: "form.materialAuthorId"
    }
  }, _vm._l(_vm.authorUserList, function (item, index) {
    return _c('el-option', {
      key: index,
      attrs: {
        "value": item.userId,
        "label": item.userName
      }
    }, [_vm._v(_vm._s(item.userName) + " ")]);
  }), 1)], 1), _c('el-form-item', {
    attrs: {
      "label": "素材信息"
    }
  }, [_c('nmg-input', {
    attrs: {
      "disabled": "",
      "type": "textarea",
      "rows": "9"
    },
    model: {
      value: _vm.materialInfo,
      callback: function callback($$v) {
        _vm.materialInfo = $$v;
      },
      expression: "materialInfo"
    }
  })], 1)], 1), _c('span', {
    staticClass: "dialog-footer",
    attrs: {
      "slot": "footer"
    },
    slot: "footer"
  }, [_c('el-button', {
    attrs: {
      "type": "primary"
    },
    on: {
      "click": _vm.save
    }
  }, [_vm._v("保 存")]), _c('el-button', {
    on: {
      "click": function click($event) {
        _vm.visible = false;
      }
    }
  }, [_vm._v("取 消")])], 1)], 1);
};
var staticRenderFns = [];


/***/ }),

/***/ "b66b":
/*!******************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/config/ports.js ***!
  \******************************************************************/
/*! exports provided: searchMaterialDetailInfo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchMaterialDetailInfo", function() { return searchMaterialDetailInfo; });
/* harmony import */ var _request_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/request/request */ "3b11");


/* 素材报表——查询素材路径*/
var searchMaterialDetailInfo = function searchMaterialDetailInfo() {
  for (var _len = arguments.length, params = new Array(_len), _key = 0; _key < _len; _key++) {
    params[_key] = arguments[_key];
  }
  return _request_request__WEBPACK_IMPORTED_MODULE_0__["post"].apply(void 0, ['/statistics/ad/platform/statistics/material/get/MaterialDetailInfo'].concat(params));
};

/***/ }),

/***/ "b77a":
/*!*********************************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/materialClaim.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_materialClaim_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./materialClaim.vue?vue&type=script&lang=js& */ "f39d5");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_materialClaim_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "bb0e":
/*!********************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/materialClaim.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _materialClaim_vue_vue_type_template_id_71cbe771___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./materialClaim.vue?vue&type=template&id=71cbe771& */ "197e");
/* harmony import */ var _materialClaim_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./materialClaim.vue?vue&type=script&lang=js& */ "b77a");
/* empty/unused harmony star reexport *//* harmony import */ var _materialClaim_vue_vue_type_style_index_0_id_71cbe771_prod_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./materialClaim.vue?vue&type=style&index=0&id=71cbe771&prod&lang=scss& */ "93f6");
/* harmony import */ var _node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "0c7c");






/* normalize component */

var component = Object(_node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _materialClaim_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _materialClaim_vue_vue_type_template_id_71cbe771___WEBPACK_IMPORTED_MODULE_0__["render"],
  _materialClaim_vue_vue_type_template_id_71cbe771___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "bf53":
/*!*************************************************************************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/dialogBatchDistribution/dialogBatchDistribution.vue?vue&type=template&id=17848e4d& ***!
  \*************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_dialogBatchDistribution_vue_vue_type_template_id_17848e4d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"1676cf96-vue-loader-template"}!../../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../../node_modules/babel-loader/lib!../../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/loaders/templateLoader.js??ref--8!../../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./dialogBatchDistribution.vue?vue&type=template&id=17848e4d& */ "b582");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_dialogBatchDistribution_vue_vue_type_template_id_17848e4d___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_1676cf96_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_8_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_dialogBatchDistribution_vue_vue_type_template_id_17848e4d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "c801":
/*!***********************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/dialogBatchDistribution/ports.js ***!
  \***********************************************************************************/
/*! exports provided: material, doSearchMaterialAuthorForSelect */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "material", function() { return material; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "doSearchMaterialAuthorForSelect", function() { return doSearchMaterialAuthorForSelect; });
/* harmony import */ var _request_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/request/request */ "3b11");


// 认领素材
var material = function material() {
  for (var _len = arguments.length, params = new Array(_len), _key = 0; _key < _len; _key++) {
    params[_key] = arguments[_key];
  }
  return _request_request__WEBPACK_IMPORTED_MODULE_0__["post"].apply(void 0, ['/statistics/ad/platform/statistics/materialClaim/claim/material'].concat(params));
};
/* 查询素材库作者下拉列表数据 */
var doSearchMaterialAuthorForSelect = function doSearchMaterialAuthorForSelect() {
  for (var _len2 = arguments.length, params = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    params[_key2] = arguments[_key2];
  }
  return _request_request__WEBPACK_IMPORTED_MODULE_0__["post"].apply(void 0, ["/material/ad/platform/transfer/material/MaterialManage/searchMaterialAuthorForSelect"].concat(params));
};

/***/ }),

/***/ "d9b4":
/*!*****************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/config/data.js ***!
  \*****************************************************************/
/*! exports provided: columns, materialType, paneList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "columns", function() { return columns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "materialType", function() { return materialType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "paneList", function() { return paneList; });
// 列数据
var columns = [{
  type: 'selection',
  'min-width': 50,
  fixed: 'left'
}, {
  prop: 'materialUrl',
  label: '素材',
  'width': 80,
  fixed: 'left'
}, {
  prop: 'materialId',
  label: '素材ID',
  'min-width': 180,
  'show-overflow-tooltip': true
}, {
  prop: 'materialName',
  label: '素材名称',
  'min-width': 220,
  'show-overflow-tooltip': true
}, {
  prop: 'placingAccountId',
  label: '投放账户',
  'min-width': 220,
  'show-overflow-tooltip': true
}, {
  prop: 'productName',
  label: '产品',
  'min-width': 160,
  'show-overflow-tooltip': true
}, {
  prop: 'materialType',
  label: '素材类型',
  'min-width': 160,
  'show-overflow-tooltip': true
}, {
  prop: 'charge',
  label: '消耗',
  'min-width': 160,
  sortable: 'custom',
  'show-overflow-tooltip': true
}, {
  prop: 'operation',
  label: '操作',
  'min-width': 160,
  fixed: 'right'
}];
var materialType = {
  1: '视频',
  2: '图片'
};
var paneList = [{
  label: '快手',
  value: '1'
}, {
  label: '头条',
  value: '2'
}, {
  label: '广点通',
  value: '3'
}];

/***/ }),

/***/ "dcd2":
/*!*******************************************************************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/dialogBatchDistribution/dialogBatchDistribution.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_dialogBatchDistribution_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../../node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!../../../../../../node_modules/babel-loader/lib!../../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!../../../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./dialogBatchDistribution.vue?vue&type=script&lang=js& */ "44f2");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_vue_cli_plugin_babel_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_node_modules_vue_cli_service_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unocss_3Awebpack_dialogBatchDistribution_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "e80d":
/*!******************************************************************************************************!*\
  !*** ./src/views/system/auxiliary/materialClaim/dialogBatchDistribution/dialogBatchDistribution.vue ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _dialogBatchDistribution_vue_vue_type_template_id_17848e4d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dialogBatchDistribution.vue?vue&type=template&id=17848e4d& */ "bf53");
/* harmony import */ var _dialogBatchDistribution_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dialogBatchDistribution.vue?vue&type=script&lang=js& */ "dcd2");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/@vue/cli-service/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "0c7c");





/* normalize component */

var component = Object(_node_modules_vue_cli_service_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _dialogBatchDistribution_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _dialogBatchDistribution_vue_vue_type_template_id_17848e4d___WEBPACK_IMPORTED_MODULE_0__["render"],
  _dialogBatchDistribution_vue_vue_type_template_id_17848e4d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "f39d5":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/@vue/cli-plugin-babel/node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/@vue/cli-service/node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unocss%3Awebpack!./src/views/system/auxiliary/materialClaim/materialClaim.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function($) {/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "2f62");
/* harmony import */ var _searchForm_searchForm_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./searchForm/searchForm.vue */ "36b5");
/* harmony import */ var _dialogBatchDistribution_dialogBatchDistribution_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dialogBatchDistribution/dialogBatchDistribution.vue */ "e80d");
/* harmony import */ var _config_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./config/store */ "4423");
/* harmony import */ var _config_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./config/data */ "d9b4");
/* harmony import */ var _config_ports__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./config/ports */ "b66b");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }






/* harmony default export */ __webpack_exports__["default"] = ({
  name: "materialClaim",
  components: {
    formSearch: _searchForm_searchForm_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    dialogBatchDistribution: _dialogBatchDistribution_dialogBatchDistribution_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      columns: this.$deepCopy(_config_data__WEBPACK_IMPORTED_MODULE_4__["columns"]),
      paramConfig: {
        pageIndex: 'pageNumber',
        pageSize: 'pageSize',
        prop: 'orderField',
        order: 'sort',
        ascending: 1,
        descending: 0
      },
      responseConfig: {
        data: 'data.objectData.records',
        summary: 'data.objectData.totalData',
        total: 'data.objectData.total'
      },
      defaultSort: {
        prop: 'charge',
        order: 'descending'
      },
      selection: [],
      targets: [],
      container: null,
      materialType: _config_data__WEBPACK_IMPORTED_MODULE_4__["materialType"]
    };
  },
  computed: _objectSpread(_objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapState"])({
    searchFormData: function searchFormData(state) {
      return state.materialClaim.searchFormData;
    },
    isRefresh: function isRefresh(state) {
      return state.materialClaim.isRefresh;
    },
    activeName: function activeName(state) {
      return state.materialClaim.activeName;
    }
  })), {}, {
    params: function params() {
      var vm = this;
      var params = vm.$deepCopy(vm.searchFormData);
      params.mediaType = vm.activeName;
      return params;
    }
  }),
  watch: {
    // 主动刷新表格数据
    isRefresh: {
      handler: function handler() {
        this.$refs.table.refresh();
      }
    }
  },
  methods: {
    /**
     * 获取合计信息
     */
    getSummaries: function getSummaries(param) {
      var summary = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var vm = this;
      var columns = param.columns,
        data = param.data;
      var sums = [];
      columns.forEach(function (column, index) {
        if (index === 0) {
          sums[index] = '总计';
          return;
        } else if (summary[column.property]) {
          sums[index] = summary[column.property];
          return;
        } else {
          sums[index] = '--';
        }
      });
      return sums;
    },
    onSelectionChange: function onSelectionChange(rows) {
      this.selection = rows;
    },
    onClickBatchDistribution: function onClickBatchDistribution(rows) {
      this.$refs.dialogBatchDistribution.open(rows);
    },
    onLoaded: function onLoaded(data) {
      this.onRendered();
    },
    onRendered: function onRendered() {
      var vm = this;
      setTimeout(function () {
        vm.$nextTick(function () {
          var _vm$$refs, _vm$$refs$table;
          var el = (_vm$$refs = vm.$refs) === null || _vm$$refs === void 0 ? void 0 : (_vm$$refs$table = _vm$$refs.table) === null || _vm$$refs$table === void 0 ? void 0 : _vm$$refs$table.$el;
          if (el) {
            var headers = $(el).find('.el-table__header-wrapper');
            var fixedHeaders = $(el).find('.el-table__fixed-header-wrapper');
            vm.targets = [].concat(_toConsumableArray(headers), _toConsumableArray(fixedHeaders));
          }
        });
      }, 200);
    },
    onClickMaterialUrlVideo: function onClickMaterialUrlVideo(row) {
      var vm = this;
      if ('2' !== vm.activeName) return;
      Object(_config_ports__WEBPACK_IMPORTED_MODULE_5__["searchMaterialDetailInfo"])({
        advertiserId: row.placingAccountId,
        // 投放户id
        ttMaterialId: row.materialId,
        // 头条媒体id
        materialType: row.materialType // 素材类型
      }, {
        clearLoading: true
      }).then(function (res) {
        var _res$data$objectData, _res$data$objectData$;
        var records = (_res$data$objectData = res.data.objectData) === null || _res$data$objectData === void 0 ? void 0 : (_res$data$objectData$ = _res$data$objectData.ttVideoFileGetVo) === null || _res$data$objectData$ === void 0 ? void 0 : _res$data$objectData$.records;
        if (records && records.length) {
          if (records[0].videoUrl) vm.$set(row, '_materialUrl', records[0].videoUrl);
        } else {
          vm.$message({
            type: "error",
            message: '视频/图片无法展示！'
          });
        }
      });
    }
  },
  beforeCreate: function beforeCreate() {
    if (this.$store.hasModule(this.$options.name)) {
      this.$store.unregisterModule(this.$options.name);
    }
    this.$store.registerModule(this.$options.name, this.$deepCopy(_config_store__WEBPACK_IMPORTED_MODULE_3__["default"]));
  },
  mounted: function mounted() {
    var vm = this;
    vm.$nextTick(function () {
      vm.container = $('.nmg-view')[0];
    });
  }
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! jquery */ "1157")))

/***/ })

}]);